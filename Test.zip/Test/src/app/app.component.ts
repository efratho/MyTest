import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Test';
  myList:any[]=[];
  checked:boolean[]=[];
  checkedItems:any[]=[];
  listToDisplay:any[]=[];
  search:string;
  constructor() {
  }
  ngOnInit(){
    this.myList=[
      {code:1, teur:'AAA'},{code:2, teur:'BBB'},{code:3, teur:'CCDC'},{code:4, teur:'DDG'},{code:5, teur:'EE'},
      {code:6, teur:'FFF'},{code:7, teur:'GGT'},{code:8, teur:'HHH'},{code:9, teur:'IIII'},{code:10, teur:'FFF'},
      {code:11, teur:'KKK'},{code:12, teur:'AALLA'},{code:13, teur:'JJJ'},{code:14, teur:'TT'},{code:15, teur:'YYY'},
      {code:16, teur:'WWW'},{code:17, teur:'RRR'},{code:18, teur:'L,,,'},{code:19, teur:'OPO'},{code:20, teur:'UUUU'},
    ];
    // this.myList=['','','','FFFKG','RGRJII',
    // 'GGGF','BBB','RTFF','DDG','YYYJ','RRR','NNNMN','CCDC','FEY','GGG','TFS','XXS','CCCC','UUIO','SSEW'];
     this.listToDisplay=this.myList;
    
    this.checkedItems=[];
  }
  changeColor(item:any){
    this.checked[item.code]=true;
    for (let i = 0; i < this.checkedItems.length; i++) {
         if(this.checkedItems[i].code==item.code){
           var index=this.checkedItems.findIndex(x => x.code === item.code);
           this.checkedItems.splice(index,1);
           this.checked[item.code]=false;
           return;
         }
}
    this.checkedItems.push(item);
  }
  searchList(type:number){
    this.listToDisplay=[];
    if(type==0)
    this.listToDisplay=this.myList;
    else if(type==1)
    this.listToDisplay=this.checkedItems;
    else {
      let j,i;
      for ( i= 0; i < this.myList.length; i++) {
        for (j = 0; j < this.checkedItems.length; j++) {
          if(this.checkedItems[j]==this.myList[i])
          break;
        }
        if(j==this.checkedItems.length)
        this.listToDisplay.push(this.myList[i]);
        
      }
    }

  }
  searchByText(){
    this.listToDisplay=[];
    this.myList.forEach(x=>{
      if(x.teur.includes(this.search))
      this.listToDisplay.push(x);
    })
  }

}
